GlobalSpeedMultiplier = {}
GlobalSpeedMultiplier.MULTIPLIER = 2.0 -- 200% increase

------------------------------------------------------------
-- Function hooks
------------------------------------------------------------

-- Working / field speed
function GlobalSpeedMultiplier.getSpeedLimit(superFunc, self, onlyIfWorking)
    local original = superFunc(self, onlyIfWorking)
    if original ~= nil then
        return original * GlobalSpeedMultiplier.MULTIPLIER
    end
    return original
end

-- Base XML-defined limit
function GlobalSpeedMultiplier.getRawSpeedLimit(superFunc, self)
    local original = superFunc(self)
    if original ~= nil then
        return original * GlobalSpeedMultiplier.MULTIPLIER
    end
    return original
end

-- Motorized road speed (engine top speed)
function GlobalSpeedMultiplier.getMotorMaxSpeed(superFunc, self)
    local original = superFunc(self)
    if original ~= nil then
        return original * GlobalSpeedMultiplier.MULTIPLIER
    end
    return original
end

-- Shop / UI displayed working speed
function GlobalSpeedMultiplier.getSpecValueSpeedLimit(superFunc, storeItem, realItem)
    local value, unit = superFunc(storeItem, realItem)
    if value ~= nil then
        return value * GlobalSpeedMultiplier.MULTIPLIER, unit
    end
    return value, unit
end

-- Shop / UI displayed max speed
function GlobalSpeedMultiplier.getSpecValueMaxSpeed(superFunc, storeItem, realItem)
    local value, unit = superFunc(storeItem, realItem)
    if value ~= nil then
        return value * GlobalSpeedMultiplier.MULTIPLIER, unit
    end
    return value, unit
end

------------------------------------------------------------
-- Entry point
------------------------------------------------------------
function GlobalSpeedMultiplier:loadMap(name)
    print(string.format("[GlobalSpeedMultiplier] Activating global speed multiplier (x%.2f)...", GlobalSpeedMultiplier.MULTIPLIER))

    if Vehicle ~= nil then
        ------------------------------------------------------------
        -- Core speed limits
        ------------------------------------------------------------
        if Vehicle.getSpeedLimit ~= nil then
            Vehicle.getSpeedLimit = Utils.overwrittenFunction(Vehicle.getSpeedLimit, GlobalSpeedMultiplier.getSpeedLimit)
            print("[GlobalSpeedMultiplier] Hooked Vehicle.getSpeedLimit.")
        else
            print("[GlobalSpeedMultiplier] ERROR: Vehicle.getSpeedLimit not found.")
        end

        if Vehicle.getRawSpeedLimit ~= nil then
            Vehicle.getRawSpeedLimit = Utils.overwrittenFunction(Vehicle.getRawSpeedLimit, GlobalSpeedMultiplier.getRawSpeedLimit)
            print("[GlobalSpeedMultiplier] Hooked Vehicle.getRawSpeedLimit.")
        else
            print("[GlobalSpeedMultiplier] WARNING: Vehicle.getRawSpeedLimit not found.")
        end

        ------------------------------------------------------------
        -- Shop display functions (so UI shows multiplied values)
        ------------------------------------------------------------
        if Vehicle.getSpecValueSpeedLimit ~= nil then
            Vehicle.getSpecValueSpeedLimit = Utils.overwrittenFunction(Vehicle.getSpecValueSpeedLimit, GlobalSpeedMultiplier.getSpecValueSpeedLimit)
            print("[GlobalSpeedMultiplier] Hooked Vehicle.getSpecValueSpeedLimit (shop working speed).")
        else
            print("[GlobalSpeedMultiplier] WARNING: Vehicle.getSpecValueSpeedLimit not found.")
        end

        if Vehicle.getSpecValueMaxSpeed ~= nil then
            Vehicle.getSpecValueMaxSpeed = Utils.overwrittenFunction(Vehicle.getSpecValueMaxSpeed, GlobalSpeedMultiplier.getSpecValueMaxSpeed)
            print("[GlobalSpeedMultiplier] Hooked Vehicle.getSpecValueMaxSpeed (shop max speed).")
        else
            print("[GlobalSpeedMultiplier] WARNING: Vehicle.getSpecValueMaxSpeed not found.")
        end
    else
        print("[GlobalSpeedMultiplier] ERROR: Vehicle table not available.")
    end

    ------------------------------------------------------------
    -- Motorized specialization (top-speed limiter)
    ------------------------------------------------------------
    if Motorized ~= nil and Motorized.getMaxSpeed ~= nil then
        Motorized.getMaxSpeed = Utils.overwrittenFunction(Motorized.getMaxSpeed, GlobalSpeedMultiplier.getMotorMaxSpeed)
        print("[GlobalSpeedMultiplier] Hooked Motorized.getMaxSpeed.")
    else
        print("[GlobalSpeedMultiplier] WARNING: Motorized.getMaxSpeed not found.")
    end
end

addModEventListener(GlobalSpeedMultiplier)
